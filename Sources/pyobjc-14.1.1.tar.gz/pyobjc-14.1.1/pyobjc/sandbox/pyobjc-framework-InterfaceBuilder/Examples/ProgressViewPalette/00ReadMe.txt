===================
ProgressViewPalette 
===================

---------------------------------
A simple InterfaceBuilder palette
---------------------------------

This example shows how to implement an InterfaceBuilder palette in Python.

It is a translation in Python of the Apple example with the same name.
