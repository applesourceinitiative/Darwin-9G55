
Relocation section '.rel.*text' at offset 0x.* contains 1 entries:
 Offset     Info    Type            Sym.Value  Sym. Name.*
00000004  [0-9A-Fa-f]+ *R_.*00000000   external_symbol.*
